import { ICommandName } from 'selenium-webdriver';

export interface Quotes {
    id: string;
    person: string;
    text: string;
}
